function hello() {
  console.log("Elizaveta Kim");
}

function sayHello(name) {
  let lastName = "Elizaveta";
  console.log("Hello " + name + " " + lastName + "!!");
}

function sum(num1, num2) {
  console.log(num1 + num2);
}
function exec1() {
  //print numbers from 0 to 20
  //except 7 and 13
  for (let i = 0; i < 21; i++) {
    if (i != 7 && i != 13) {
      console.log(i);
    }
  }
  let name = "";

  if (!name) {
    console.error("Name is required");
  }
}
function exce2() {
  let numbers = [123, 3, -1, 12, -123, 45, 10, 20, 203, -2, -29, 12, 123];
  // a ptont every number in the array
  for (let i = 0; i < numbers.length; i++) {
    let number = numbers[i];
    console.log(number);
    total = total + number;

    if (number < 0) {
      console.log("Is negative", item);
    }
  }
  console.log(total);
}

function init() {
  console.log("Intro page!");

  hello();

  let myName = "Elizaveta";
  sayHello(myName); // Hello Elizaveta

  let res = sum(21, 12);
  console.log(res);
  //console log 42
  //access any Dom element
  exec1();
}
window.onload = init;
