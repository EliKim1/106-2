var importantIconClass = "fa-regular fa-star";
var nonImportantIconClass = "fa-solid fa-star";
var isImportant = false;




function toggleImportant(){
    console.log('Icon clicked');

    if (!isImportant){
                            // Change to important

        $('#iImportant').removeClass(importantIconClass); //remove non- important icon classess
        $('#iImportant').addClass(nonImportantIconClass); //remove non- important icon classess
        isImportant = True;
    }

    else{
        //change to non important
        $('#iImportant').removeClass(nonImportantIconClass); //remove non- important icon classess
        $('#iImportant').Class(importantIconClass); //remove non- important icon classess
        isImportant = False;

    }
}

function init() {
    console.log('Task Manager page!');

    $('#iImportant').click(toggleImportant);
}

window.onload = init;